from pathlib import Path
import datetime, hashlib, json, os, re, subprocess, sys
OUT=Path(__file__).resolve().parent
B=json.loads((OUT/'BASELINE.json').read_text())
WORK=Path(B['worktree']); SOURCE=Path(B['source_repo']); BASE=B['BASE_COMMIT']
ALLOWED={'repo_index/symbols.py','tests/test_repo_index_symbols.py','docs/repo-explorer/SYMBOLS.md'}
ENV={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
def git(repo,*a):
    return subprocess.check_output(['git','--no-optional-locks','-c','core.fsmonitor=false','-C',str(repo),*a],text=True).strip()
assert git(WORK,'branch','--show-current')=='feat/repo-explorer-symbols-v1'
assert git(WORK,'merge-base',BASE,'HEAD')==BASE
assert git(SOURCE,'rev-parse','HEAD')==B['source_HEAD']
assert git(SOURCE,'rev-parse','refs/heads/main')==B['source_main']
assert git(SOURCE,'status','--porcelain')==B['source_status']
cmd=[sys.executable,'-B','-m','unittest','discover','-s','tests','-p','test_repo_index_symbols.py','-v']
ran=subprocess.run(cmd,cwd=WORK,env=ENV,capture_output=True,text=True)
log=ran.stdout+ran.stderr
(OUT/'tests-final.log').write_text(log)
assert ran.returncode==0,log
count=int(re.search(r'Ran (\d+) tests',log).group(1))
assert count==17,count
# Run only the public caller example, which parses a source string, never
# executing the class/function contained inside that string.
doc=(WORK/'docs/repo-explorer/SYMBOLS.md').read_text()
fence=chr(96)*3
example=re.search(fence+r'python\n(.*?)\n'+fence,doc,re.S).group(1)
probe=subprocess.run([sys.executable,'-B','-c',example+'\nimport json\nprint(json.dumps(result,ensure_ascii=False))'],cwd=WORK,env=ENV,capture_output=True,text=True)
(OUT/'integration-example.log').write_text(probe.stdout+probe.stderr)
assert probe.returncode==0,probe.stderr
actual=json.loads(probe.stdout)
expected_doc=json.loads(re.search(fence+r'json\n(.*?)\n'+fence,doc,re.S).group(1))
assert actual==expected_doc,(actual,expected_doc)
subprocess.run(['git','-C',str(WORK),'add','--',*sorted(ALLOWED)],check=True)
changed=set(git(WORK,'diff','--name-only',BASE).splitlines())
assert changed==ALLOWED,changed
diff_check=subprocess.run(['git','-C',str(WORK),'diff','--cached','--check'],capture_output=True,text=True)
assert diff_check.returncode==0,diff_check.stdout+diff_check.stderr
name=git(SOURCE,'show','-s','--format=%an','80e091acefd278fda03e188a125147b0aa5eedc5')
email=git(SOURCE,'show','-s','--format=%ae','80e091acefd278fda03e188a125147b0aa5eedc5')
committed=subprocess.run(['git','-c','user.name='+name,'-c','user.email='+email,'-C',str(WORK),'commit','-m','fix(symbols): report NUL lines and complete contract checks'],capture_output=True,text=True)
assert committed.returncode==0,committed.stdout+committed.stderr
head=git(WORK,'rev-parse','HEAD')
commits=git(WORK,'rev-list','--reverse',BASE+'..HEAD').splitlines()
assert len(commits)==2,commits
assert git(WORK,'status','--porcelain')==''
assert git(SOURCE,'rev-parse','refs/heads/main')==B['source_main']
assert git(SOURCE,'rev-parse','HEAD')==B['source_HEAD']
assert git(SOURCE,'status','--porcelain')==B['source_status']
bundle=OUT/'B-symbols-v1.bundle'
subprocess.run(['git','-C',str(WORK),'bundle','create',str(bundle),'feat/repo-explorer-symbols-v1','^'+BASE],check=True,capture_output=True,text=True)
verify=subprocess.run(['git','-C',str(WORK),'bundle','verify',str(bundle)],capture_output=True,text=True)
(OUT/'bundle-verify.log').write_text(verify.stdout+verify.stderr)
assert verify.returncode==0,verify.stdout+verify.stderr
files=git(WORK,'diff','--name-only',BASE,head).splitlines()
assert set(files)==ALLOWED
result={'ROLE':'B','STATUS':'READY','ACTUAL_CHECKOUT':str(WORK),'BRANCH':'feat/repo-explorer-symbols-v1','BASE_COMMIT':BASE,'COMMITS':commits,'FINAL_HEAD':head,'CHANGED_FILES':files,'PUBLIC_INTERFACE':'repo_index.symbols.parse_symbols(path: str, source: str) -> dict','CHECKS_RUN':[{'command':cmd,'cwd':str(WORK),'exit_code':ran.returncode,'result':'17 tests PASS','log':str(OUT/'tests-final.log')},{'command':'documentation public-import example + exact JSON comparison','result':'PASS','log':str(OUT/'integration-example.log')},{'command':'git diff --cached --check + exact allowed-file scope','result':'PASS'},{'command':'git bundle verify '+str(bundle),'result':'PASS','log':str(OUT/'bundle-verify.log')}],'CHECKS_NOT_RUN':[{'check':'A integrated HTTP/UI/application runtime','reason':'B-only pure parser task; A integration and D product acceptance'},{'check':'all historical repository tests','reason':'No shared runtime/history module changed; targeted parser contract verified'},{'check':'Python3.10/3.11/other platforms','reason':'Actual execution used bundled Python '+sys.version.split()[0]}],'LIMITATIONS':['Grammar follows actual Python interpreter','Only .py/.pyi text; lexical definitions, not runtime calls/business architecture','Caller handles repo/revision/path/decoding/size','Non-string inputs raise TypeError; language python denotes parser identity','No automatic push/PR/main modification'],'PROJECT_MODEL_IMPACT':'UPDATE','PROJECT_MODEL_IMPACT_REASON':'New technical parser implementation and public source-only entry; formal model unchanged, team confirms integration/status record','HANDOFF':{'bundle':str(bundle),'prerequisite':BASE,'steps':['Import bundle into A own integration checkout Git object store','Apply listed two commits in order','Call B with decoded text from same selected repo/full SHA','A wraps projectId/revision/parser=python_ast_v1 and verifies HTTP/UI']},'MAIN_SOURCE_HEAD_UNCHANGED':True,'MAIN_BRANCH_SHA_UNCHANGED':True,'SOURCE_WORKTREE_UNCHANGED':True,'timestampUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'git_diff_stat':git(WORK,'diff','--stat',BASE,head),'bundle_sha256':hashlib.sha256(bundle.read_bytes()).hexdigest(),'bundle_bytes':bundle.stat().st_size,'review':'Independent review found NUL missing line; fixed and LF/CRLF/CR test passed. Other 5 independent contract probes passed.','early_failures':'Test before module creation had ModuleNotFoundError; later basic/final tests pass. One manual CLI probe had quoting error; corrected direct validation and final tests pass. Final delivery script first JS template quoting attempt failed before execution; rewritten safely, no Git/code side effects.'}
(OUT/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
(OUT/'COMMITS.json').write_text(json.dumps([{'stage':'first usable delivery','sha':commits[0]},{'stage':'complete B contract/tests/docs','sha':commits[1]}],ensure_ascii=False,indent=2))
print(json.dumps({k:result[k] for k in ['ROLE','STATUS','ACTUAL_CHECKOUT','BRANCH','COMMITS','CHANGED_FILES','MAIN_SOURCE_HEAD_UNCHANGED','MAIN_BRANCH_SHA_UNCHANGED','bundle_bytes','bundle_sha256']},ensure_ascii=False,indent=2))

