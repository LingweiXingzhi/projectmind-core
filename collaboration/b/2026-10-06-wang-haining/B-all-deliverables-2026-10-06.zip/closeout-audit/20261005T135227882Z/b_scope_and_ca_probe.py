from pathlib import Path
import hashlib,importlib.util,json,os,sys
ROOT=Path(__file__).resolve().parent;R=json.loads((ROOT/'runtime-config.json').read_text());V=json.loads((ROOT/'versions.json').read_text())
sys.dont_write_bytecode=True;sys.path.insert(0,V['BCD']['copy'])
from extensions.code_facts import facts as b
from extensions.map_proposal import engine
from extensions.context_authority.context_pack import validate_context_pack
cfg=R['BCD'];repo=Path(cfg['target_repository']);records=[];original=b._git
for selected in [None,['user.py'],[]]:
    calls=[]
    def observed_git(repo,*args):
        raw=original(repo,*args)
        calls.append({'args':list(args),'returned_bytes':len(raw),'tree_rows':len([x for x in raw.split(b'\0') if x]) if args and args[0]=='ls-tree' else None})
        return raw
    b._git=observed_git
    try:result=b.collect_code_facts(repo,cfg['target_revision'],selected)
    finally:b._git=original
    records.append({'paths':selected,'output_files':len(result['files']),'definitions':sum(len(f['entries']) for f in result['files']),'git_calls':calls})
(ROOT/'evidence/B-scan-scope.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
folder=ROOT/'evidence/http-BCD';pack=json.loads((folder/'CA-context.json').read_text())['body']
compare=json.loads((folder/'compare.json').read_text())['body'];current_map=json.loads(Path(cfg['map']).read_text())
validation=validate_context_pack(pack,cfg['target_revision'])
proposal=engine.suggest_map(repo,{**compare,'current_map':current_map,'context_pack':pack})
direct={'source_sha':V['BCD']['sha'],'target_revision':cfg['target_revision'],'mode':'DEVELOPER_ONLY_CONTINUATION: direct Python calls bypass HTTP request limit; not user-chain success','validation':validation,'proposal':proposal}
(ROOT/'evidence/CA-direct-python.json').write_text(json.dumps(direct,ensure_ascii=False,indent=2))
hashes={}
for key in ['B','BCD','UI','C','CA','D','A30']:
    p=Path(V[key]['copy']);hashes[key]={}
    for rel in ['extensions/code_facts/facts.py','extensions/map_proposal/engine.py','extensions/context_authority/context_pack.py','extension_host.py','extensions/continuity/model.py']:
        f=p/rel
        if f.exists():hashes[key][rel]=hashlib.sha256(f.read_bytes()).hexdigest()
(ROOT/'evidence/module-byte-identities.json').write_text(json.dumps(hashes,indent=2))
print(json.dumps({'scope':[{'paths':x['paths'],'output_files':x['output_files'],'definitions':x['definitions'],'tree_rows':[c['tree_rows'] for c in x['git_calls'] if c['tree_rows'] is not None]} for x in records],
    'direct_CA_validation':{k:v for k,v in validation.items() if k in ['valid','status','schema_version','project_revision']},
    'direct_C_with_CA':{'status':proposal['status'],'context_mode':proposal.get('context',{}).get('context_mode'), 'keys':list(proposal),'proposal_count':len(proposal['proposals'])}},ensure_ascii=False,indent=2))
