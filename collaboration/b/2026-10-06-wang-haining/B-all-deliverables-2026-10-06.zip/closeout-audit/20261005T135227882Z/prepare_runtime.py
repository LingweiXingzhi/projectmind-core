from pathlib import Path
import datetime,hashlib,json,os,socket,subprocess,sys,time
from urllib.request import urlopen

ROOT=Path(__file__).resolve().parent;C=json.loads((ROOT/'run-config.json').read_text());V=json.loads((ROOT/'versions.json').read_text())
SB=Path(C['SANDBOX_ROOT']); env={k:v for k,v in os.environ.items() if not k.startswith('OPENAI_') and k!='PROJECTMIND_AI_MODEL'}
env.update(PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(SB/'tmp'),TEMP=str(SB/'tmp'),TMP=str(SB/'tmp'),XDG_CACHE_HOME=str(SB/'cache'),GIT_TERMINAL_PROMPT='0')
def git(repo,*args):
    return subprocess.check_output(['git','-C',str(repo),'-c','user.name=Audit B Test','-c','user.email=audit-b@example.invalid','-c','core.hooksPath=/dev/null','-c','commit.gpgsign=false',*args],env=env,text=True).strip()

template=SB/'targets'/'seed';template.mkdir(parents=True)
git(template,'init','-b','main')
texts={'user.py':'def load_user():\n    return {"name": "TEST_FIXTURE"}\n',
       'service.py':'from user import load_user\n\ndef execute():\n    return load_user()\n','README.md':'Safe Audit B fixture, not production.\n'}
texts.update({f'unchanged/file{i:02d}.py':f'def stable_{i}():\n    return {i}\n' for i in range(30)})
for path,text in texts.items():
    file=template/path;file.parent.mkdir(exist_ok=True);file.write_text(text)
git(template,'add','.');git(template,'commit','-m','TEST_FIXTURE initial two functional nodes')
base=git(template,'rev-parse','HEAD')
(template/'user.py').write_text(texts['user.py']+'\nasync def fetch_user():\n    return load_user()\n')
(template/'new_tools.py').write_text('from user import load_user\n\ndef helper():\n    return load_user()\n')
git(template,'add','.');git(template,'commit','-m','TEST_FIXTURE add async definition and helper')
target=git(template,'rev-parse','HEAD')
curated={'note':'TEST_FIXTURE: manually prepared map for isolated audit; not formal Project Model',
    'nodes':[{'id':'user','title':'用户读取','summary':'测试用户数据','entryPoint':'user.py · load_user()',
              'position':{'x':30,'y':80},'evidence':[{'path':'user.py','reason':'manual fixture'}]},
             {'id':'service','title':'测试服务','summary':'调用用户读取','entryPoint':'service.py · execute()',
              'position':{'x':280,'y':80},'evidence':[{'path':'service.py','reason':'manual fixture'}]}],
    'edges':[{'from':'service','to':'user','label':'manual fixture relation'}]}
result={};processes=[]
for key,port in [('main',18820),('B',18821),('BCD',18822),('UI',18823)]:
    repo=SB/'targets'/key
    subprocess.run(['git','clone','--no-hardlinks',str(template),str(repo)],env=env,check=True,capture_output=True)
    git(repo,'remote','set-url','origin','https://example.invalid/audit-B/test.git')
    git(repo,'update-ref','refs/remotes/origin/main',base)
    common=Path(git(repo,'rev-parse','--path-format=absolute','--git-common-dir'));assert common.is_relative_to(SB)
    map_path=SB/'targets'/(key+'-map.json');map_path.write_text(json.dumps(curated,ensure_ascii=False,indent=2))
    source=Path(V[key]['copy'])
    # The no-map attempt is a real CLI bootstrap observation, not a guessed gap.
    failure=subprocess.run([sys.executable,str(source/'app.py'),'--repo',str(repo),'--port',str(port)],env=env,capture_output=True,text=True,timeout=15)
    (ROOT/'evidence'/('no-map-'+key+'.txt')).write_text(failure.stdout+failure.stderr)
    assert failure.returncode!=0
    check=socket.socket();check.bind(('127.0.0.1',port));check.close()
    command=[sys.executable,str(source/'app.py'),'--repo',str(repo),'--map',str(map_path),'--port',str(port)]
    stream=(ROOT/'evidence'/('server-'+key+'.log')).open('w')
    process=subprocess.Popen(command,cwd=source,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    stream.close()
    processes.append({'version':key,'pid':process.pid,'port':port,'command':command,'source_sha':V[key]['sha'],'target':str(repo),'map':str(map_path)})
    (ROOT/'processes.json').write_text(json.dumps(processes,ensure_ascii=False,indent=2))
    for attempt in range(30):
        try:
            with urlopen(f'http://127.0.0.1:{port}/api/snapshot',timeout=1) as response:snapshot=json.load(response)
            break
        except Exception:
            if process.poll() is not None:raise RuntimeError('Service failed: '+key)
            time.sleep(.2)
    else:raise RuntimeError('Service unavailable: '+key)
    assert snapshot['revision']==target
    result[key]={'source_sha':V[key]['sha'],'target_repository':str(repo),'target_git_common_dir':str(common),
        'base_revision':base,'target_revision':target,'map':str(map_path),'map_sha256':hashlib.sha256(map_path.read_bytes()).hexdigest(),
        'map_source':'manual TEST_FIXTURE setup assistance','port':port,'pid':process.pid,
        'url':f'http://127.0.0.1:{port}','no_map_exit_code':failure.returncode,'snapshot':snapshot}
(ROOT/'runtime-config.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({key:{k:v for k,v in value.items() if k!='snapshot'} for key,value in result.items()},ensure_ascii=False,indent=2))
