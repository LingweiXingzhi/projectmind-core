from pathlib import Path
import json,hashlib
from urllib.request import Request,urlopen
from urllib.error import HTTPError
ROOT=Path(__file__).resolve().parent;R=json.loads((ROOT/'runtime-config.json').read_text());summary=[]
for key in ['BCD','UI']:
    cfg=R[key];folder=ROOT/'evidence'/('http-'+key)
    pack=json.loads((folder/'CA-context.json').read_text())['body']
    compare=json.loads((folder/'compare.json').read_text())['body']
    current_map=json.loads(Path(cfg['map']).read_text())
    attempts=[('CA-validation-utf8',{'action':'validate_context','pack':pack,'expected_revision':cfg['target_revision']},'/api/extensions/context_authority'),
      ('proposal-with-CA-utf8',{**compare,'current_map':current_map,'context_pack':pack},'/api/extensions/map_proposal'),
      ('handoff-valid-input',{'expectedRevision':cfg['target_revision'],'sourceLocator':{'kind':'local_path','value':cfg['target_repository']},'baseRevision':cfg['base_revision'],
        'workNotes':{'completed':'TEST_HUMAN_REVIEW audit only','pending':'Formal model and D1-D6 not decided','blockers':'No bootstrap map or formal acceptance','nextSteps':'Verify user.py at pinned SHA'}},'/api/extensions/handoff')]
    for label,payload,path in attempts:
        raw=json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode()
        request=Request(cfg['url']+path,data=raw,headers={'Content-Type':'application/json'},method='POST')
        try:
            with urlopen(request,timeout=30) as response:status=response.status;body=json.load(response)
        except HTTPError as exc:status=exc.code;body=json.load(exc)
        (folder/(label+'.json')).write_text(json.dumps({'status':status,'request_bytes':len(raw),'payload':payload,'body':body},ensure_ascii=False,indent=2))
        summary.append({'version':key,'label':label,'status':status,'request_bytes':len(raw),'error':body.get('error')})
(ROOT/'evidence/http-followup.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False,indent=2))
