from pathlib import Path
import datetime, hashlib, json, os, subprocess

ROOT=Path(__file__).resolve().parent
C=json.loads((ROOT/'run-config.json').read_text())
SOURCE=Path(C['SOURCE_REPOSITORY'])
SANDBOX=Path(C['SANDBOX_ROOT'])
ENV={**os.environ,'GIT_OPTIONAL_LOCKS':'0','GIT_NO_LAZY_FETCH':'1','GIT_NO_REPLACE_OBJECTS':'1','GIT_TERMINAL_PROMPT':'0'}

def git(repo,*args):
    return subprocess.check_output(['git','--no-optional-locks','-c','core.fsmonitor=false','-C',str(repo),*args],env=ENV,text=True).strip()

def snapshot(path):
    return {'path':str(path),'HEAD':git(path,'rev-parse','HEAD'),'refs':git(path,'show-ref'),
        'branch':git(path,'branch','--show-current'),'tracked':git(path,'status','--porcelain','--untracked-files=no'),
        'untracked':git(path,'ls-files','--others','--exclude-standard'),'worktrees':git(path,'worktree','list','--porcelain'),
        'file_hashes':{str(f.relative_to(path)):hashlib.sha256(f.read_bytes()).hexdigest() for f in path.rglob('*') if f.is_file() and '.git' not in f.parts},
        'git_index_hash':hashlib.sha256((path/'.git/index').read_bytes()).hexdigest()}

protected=[SOURCE,SOURCE.parent/'projectmind-core']
snap={'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repositories':[snapshot(p) for p in protected]}
(ROOT/'evidence/protected-start.json').write_text(json.dumps(snap,ensure_ascii=False,indent=2))
versions={'main':'main','B':'origin/feat/30-code-facts-integration','Core_D_history':'origin/feat/handoff-continuity',
    'C':'origin/fix/c-independent-audit-v1','CA':'origin/feat/context-authority-mvp',
    'D':'origin/fix/d-independent-audit-v1','A30':'origin/fix/core-extension-runtime-isolation',
    'BCD':'origin/integration/bcd-audit-fixes-v1','UI':'origin/fix/ui-independent-audit-v1',
    'archive':'origin/chore/workspace-normalization-2026-10-05'}
remote=json.loads((ROOT/'evidence/remote-heads-start.json').read_text())
remote_shas={r['ref']:r['object']['sha'] for r in remote['refs']}
records={}
for name,ref in versions.items():
    sha=git(SOURCE,'rev-parse',ref)
    destination=SANDBOX/'sources'/name
    destination.parent.mkdir(exist_ok=True)
    subprocess.run(['git','clone','--no-hardlinks','--no-checkout',str(SOURCE),str(destination)],env=ENV,check=True,capture_output=True)
    subprocess.run(['git','-c','core.hooksPath=/dev/null','-C',str(destination),'checkout','--detach',sha],env=ENV,check=True,capture_output=True)
    common=Path(git(destination,'rev-parse','--path-format=absolute','--git-common-dir'))
    assert common.is_relative_to(SANDBOX)
    assert not (common/'objects/info/alternates').exists()
    assert git(destination,'rev-parse','HEAD')==sha
    remote_ref='refs/heads/'+ref.removeprefix('origin/')
    records[name]={'ref':ref,'sha':sha,'copy':str(destination),'git_common_dir':str(common),
        'remote_sha':remote_shas.get(remote_ref),'remote_matches':remote_shas.get(remote_ref)==sha,
        'tracked_status':git(destination,'status','--porcelain','--untracked-files=no'),
        'untracked_status':git(destination,'ls-files','--others','--exclude-standard'),
        'ancestry_of_main':subprocess.run(['git','--no-optional-locks','-C',str(SOURCE),'merge-base','--is-ancestor',sha,git(SOURCE,'rev-parse','main')],env=ENV).returncode==0}
(ROOT/'versions.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
archive=Path(records['archive']['copy'])
files=[str(p.relative_to(archive)) for p in archive.rglob('*') if p.is_file() and '.git' not in p.parts]
(ROOT/'evidence/archive-file-index.json').write_text(json.dumps(files,ensure_ascii=False,indent=2))
topology={}
for a,b in [('BCD','UI'),('UI','BCD'),('B','BCD'),('C','BCD'),('D','BCD'),('CA','BCD'),('A30','BCD')]:
    topology[a+'_ancestor_'+b]=subprocess.run(['git','--no-optional-locks','-C',str(SOURCE),'merge-base','--is-ancestor',records[a]['sha'],records[b]['sha']],env=ENV).returncode==0
(ROOT/'evidence/topology.json').write_text(json.dumps(topology,indent=2))
print(json.dumps({'versions':records,'topology':topology},ensure_ascii=False,indent=2))
