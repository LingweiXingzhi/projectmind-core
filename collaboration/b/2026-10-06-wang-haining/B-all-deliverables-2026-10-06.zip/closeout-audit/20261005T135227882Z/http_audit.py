from pathlib import Path
import hashlib,json
from urllib.request import Request,urlopen
from urllib.error import HTTPError
from urllib.parse import urlencode
ROOT=Path(__file__).resolve().parent;R=json.loads((ROOT/'runtime-config.json').read_text());results={}

def call(key,label,path,payload=None):
    cfg=R[key];req=Request(cfg['url']+path,data=None if payload is None else json.dumps(payload).encode(),headers={} if payload is None else {'Content-Type':'application/json'})
    try:
        with urlopen(req,timeout=30) as response:status=response.status;raw=response.read()
    except HTTPError as exc:status=exc.code;raw=exc.read()
    try:body=json.loads(raw)
    except Exception:body=raw.decode(errors='replace')
    folder=ROOT/'evidence'/('http-'+key);folder.mkdir(exist_ok=True)
    artifact=folder/(label+'.json');artifact.write_text(json.dumps({'status':status,'payload':payload,'path':path,'body':body},ensure_ascii=False,indent=2))
    result={'label':label,'status':status,'artifact':str(artifact),'source_sha':cfg['source_sha'],'target_revision':cfg['target_revision']}
    results.setdefault(key,[]).append(result)
    return status,body

for key,cfg in R.items():
    _,snap=call(key,'snapshot','/api/snapshot');_,ext=call(key,'extensions','/api/extensions')
    call(key,'root-page','/');_,compare=call(key,'compare','/api/compare?'+urlencode({'base':cfg['base_revision'],'target':cfg['target_revision']}))
    call(key,'evidence-map-declared','/api/evidence?'+urlencode({'path':'user.py','revision':cfg['target_revision']}))
    call(key,'evidence-undeclared-new-file','/api/evidence?'+urlencode({'path':'new_tools.py','revision':cfg['target_revision']}))
    call(key,'export','/api/export?'+urlencode({'revision':cfg['target_revision'],'base':cfg['base_revision']}))
    if key=='main':continue
    _,facts=call(key,'code-facts-full','/api/extensions/code_facts',{'revision':cfg['target_revision']})
    call(key,'code-facts-selected','/api/extensions/code_facts',{'revision':cfg['target_revision'],'paths':['user.py']})
    call(key,'code-facts-empty','/api/extensions/code_facts',{'revision':cfg['target_revision'],'paths':[]})
    call(key,'code-facts-missing','/api/extensions/code_facts',{'revision':cfg['target_revision'],'paths':['missing.py']})
    call(key,'code-facts-head','/api/extensions/code_facts',{'revision':'HEAD'})
    call(key,'code-facts-page','/ext/code_facts')
    if key=='B':continue
    current_map=json.loads(Path(cfg['map']).read_text())
    proposal_request={**compare,'current_map':current_map}
    _,proposal=call(key,'proposal-installed-B','/api/extensions/map_proposal',proposal_request)
    call(key,'proposal-supplied-B','/api/extensions/map_proposal',{**proposal_request,'code_facts':facts})
    call(key,'proposal-mismatched-B','/api/extensions/map_proposal',{**proposal_request,'code_facts':{**facts,'revision':cfg['base_revision']}})
    call(key,'proposal-missing-map','/api/extensions/map_proposal',compare)
    _,pack=call(key,'CA-context','/api/extensions/context_authority',{'action':'context','task':'code facts map proposal audit','revision':cfg['target_revision']})
    call(key,'CA-validation','/api/extensions/context_authority',{'action':'validate_context','pack':pack,'expected_revision':cfg['target_revision']})
    call(key,'proposal-with-real-CA','/api/extensions/map_proposal',{**proposal_request,'context_pack':pack})
    call(key,'C-review-not-persisted','/api/extensions/map_proposal',{**proposal_request,'prior_decisions':[{'subject':p['subject'],'kind':p['kind'],'decision':'REJECTED'} for p in proposal.get('proposals',[])[:1]]})
    _,handoff=call(key,'handoff','/api/extensions/handoff',{'expectedRevision':cfg['target_revision'],'sourceLocator':{'kind':'local_path','value':cfg['target_repository']},'baseRevision':cfg['base_revision'],'workNotes':{'goal':'TEST_HUMAN_REVIEW only; no formal decision','completed':'isolated audit','remaining':'human architecture questions unresolved'}})
    _,log=call(key,'worklog-save','/api/extensions/worklog',{'action':'save','category':'daily','date':'2026-10-05','title':'TEST_HUMAN_REVIEW audit record','body':'No formal D1-D6 decision or model approval.','author':'Audit B test actor','origin':'human'})
    logid=log.get('entry',{}).get('id')
    task={'title':'Safe audit handoff','goal':'Review real code facts at pinned version','completed':'Compare and proposal checked','stopPoint':'Formal map unchanged; human decisions unresolved','nextAction':'Read user.py at recorded SHA','acceptance':'Verify identity, revision, and candidate status','cautions':'TEST_HUMAN_REVIEW; not architecture approval','owner':'Audit B test actor'}
    _,created=call(key,'continuity-create','/api/extensions/continuity',{'action':'create','task':task,'logIds':[logid] if logid else [],'baseRevision':cfg['base_revision'],'expectedRevision':cfg['target_revision'],'scope':['user'],'checklist':[]})
    record=created.get('record')
    if record:
        for kind in ['ready','receive','start']:
            payload={'action':'event','id':record['id'],'expectedVersion':record['version'],'kind':kind,'actor':'TEST_HUMAN_REVIEW actor','origin':'human','note':'sandbox test only','evidence':'http audit evidence'}
            if kind=='start':payload['review']={'materials':True,'environment':True,'understanding':True,'nextStep':True}
            _,updated=call(key,'continuity-'+kind,'/api/extensions/continuity',payload);record=updated.get('record',record)
        _,exported=call(key,'continuity-export','/api/extensions/continuity?'+urlencode({'action':'export','id':record['id']}))
        (ROOT/'evidence'/('recovery-packet-'+key+'.json')).write_text(json.dumps(exported,ensure_ascii=False,indent=2))
    after_hash=hashlib.sha256(Path(cfg['map']).read_bytes()).hexdigest()
    results[key].append({'label':'manual-map-unchanged','verified':after_hash==cfg['map_sha256'],'sha256':after_hash})

(ROOT/'evidence/http-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(json.dumps({key:[{k:v for k,v in item.items() if k in ('label','status','verified')} for item in rows] for key,rows in results.items()},ensure_ascii=False,indent=2))
