import json,hashlib,datetime
from pathlib import Path
r=Path(__file__).resolve().parent;e=r/'evidence'
p=e/'evidence-index.json';a=json.loads(p.read_text())
expected={
'EV01':'每个指定ref能解析到TXT期望完整SHA；验证副本common-dir独立；拓扑独立测量',
'EV02':'前后远端HEAD与所审固定版本对应；差异如实记录，不fetch/push',
'EV03':'受保护仓库HEAD/refs/登记/index/文件内容前后相同；运行源码无修改',
'EV04':'分别观察新repo无map的启动结果；辅助map后能运行真实服务并明确fixture',
'EV05':'不改现有测试或产品；保留每版原始pass/fail/error/skip及命令log',
'EV06':'Mac映射真实B/CA源根后执行此前因路径缺失未运行的consumer契约',
'EV07':'必须先建立真实缺失blob夹具，才能判定缺对象时不自动fetch/写pack行为',
'EV08':'全部30场景按现有oracle检查，两轮稳定，不把mock结果冒充用户链',
'EV09':'baseline有效、语义突变有效、guard实际失败；仅此计SEMANTIC_CAUGHT',
'EV10':'固定真实Git比较2变化；仅声明路径可读出处，拒绝未声明路径；export真实',
'EV11':'facts绑定完整commit；名称/类型/1-based定义行准确；选择/空选择边界清楚；非法输入400',
'EV12':'以实际Git命令和读取字节区分目录枚举与源码blob/AST处理，不推导token节省',
'EV13':'同版本真实B消费生成可追溯候选；错版本/缺map明确拒绝；候选与正式决定分离',
'EV14':'完整产品context包能够经当前HTTP入口验证/消费；失败须测量实际UTF8字节和host预算',
'EV15':'直接调用真实validator及C，区分语义验证能力和HTTP运输失败，不补算用户成功',
'EV16':'自有DB实际保存日志/接续事件/草稿，版本正确、可导出；TEST人审不升级正式批准',
'EV17':'通过真实UI输入/点击看到结果；各版本分别记录，未操作下载/录入不记PASS',
'EV18':'无历史receiver只读所允材料，恢复7类事实与状态；缺资料正确保留UNKNOWN，记录真实读取范围',
'EV19':'关键存在/缺失结论来自明确SHA源码路径、hash与实际消费连接；不从缺按钮猜无后端',
'EV20':'保存历史report/review与本轮结果来源差异，不自动修改旧finding',
'EV21':'指定D1-D6分别记录原问题/政策/决定触发；只统计有依据OPEN，不替人决定',
'EV22':'定位Model实际ref与批准状态；区分负责人意图/AI草稿/正式数据，给原文hash',
'EV23':'历史ACTIVE/continuity不当当前LIVE；检查缺失前提，不启动或恢复Grilling',
'EV24':'只写自有输出/sandbox，不改保护代码状态；所有监听遵守B端口范围，偏差如实记录',
'EV25':'实际map字节与D capture对应；candidate/review/log不偷写正式map；hash不冒充批准版本',
'EV26':'文档漂移有具体语句/固定版本/当前反证；按根因去重，不混不同历史scope'
}
for x in a:x['EXPECTED_RESULT']=expected[x['EVIDENCE_ID']]
p.write_text(json.dumps(a,ensure_ascii=False,indent=2))
# Retain the original self-check result and refresh hashes after the recorded log append.
check=json.loads((e/'report-self-check.json').read_text())
check['final_metadata_review_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
check['checks']['scenario_specific_expected_results']=True
check['report_sha256']=hashlib.sha256((r/'CURRENT_STATE_B.md').read_bytes()).hexdigest()
(e/'report-self-check.json').write_text(json.dumps(check,ensure_ascii=False,indent=2))
manifest=[{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(r.rglob('*')) if p.is_file() and p.name!='artifact-manifest.json']
(e/'artifact-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
assert all(Path(x['path']).exists() and hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['sha256'] for x in manifest)
print(json.dumps({'manifest_final_hashes_match':True,'files':len(manifest),'report_sha256':check['report_sha256']},ensure_ascii=False))

