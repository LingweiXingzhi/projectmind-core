from pathlib import Path
import datetime,json,os,re,subprocess,sys
ROOT=Path(__file__).resolve().parent
C=json.loads((ROOT/'run-config.json').read_text());V=json.loads((ROOT/'versions.json').read_text())
SB=Path(C['SANDBOX_ROOT']);node='<LOCAL_USER_HOME>/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin'
env={k:v for k,v in os.environ.items() if not k.startswith('OPENAI_') and k!='PROJECTMIND_AI_MODEL'}
env.update({'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(SB/'tmp'),'TEMP':str(SB/'tmp'),'TMP':str(SB/'tmp'),
    'XDG_CACHE_HOME':str(SB/'cache'),'PATH':node+os.pathsep+env['PATH'],'GIT_TERMINAL_PROMPT':'0','GIT_OPTIONAL_LOCKS':'0'})
results=[]
for key in ['main','B','BCD','UI']:
    log=ROOT/'evidence'/('tests-'+key+'.log');start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    command=[sys.executable,'-m','unittest','discover','-s','tests','-v']
    with log.open('w') as stream:
        result=subprocess.run(command,cwd=V[key]['copy'],env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
    text=log.read_text();count=re.search(r'Ran (\d+) tests? in ([\d.]+)s',text)
    item={'version':key,'sha':V[key]['sha'],'command':command,'source_copy':V[key]['copy'],'log':str(log),
        'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':result.returncode,
        'count':int(count[1]) if count else None,'seconds':float(count[2]) if count else None,
        'result_tail':'\n'.join(text.splitlines()[-12:]),'source_modification':'none',
        'test_environment':'Mac; bundled Python and Node; sandbox TEMP/cache; no API keys; existing tests unchanged',
        'ports_note':'Existing automated harnesses allocate their own kernel-selected ephemeral ports. Manual product services will use B range 18820-18839.'}
    results.append(item);(ROOT/'evidence/existing-test-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
    print(json.dumps(item,ensure_ascii=False),flush=True)
