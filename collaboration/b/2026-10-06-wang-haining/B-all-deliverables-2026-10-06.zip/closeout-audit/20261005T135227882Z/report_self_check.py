from pathlib import Path
import hashlib, json, re, datetime
root=Path(__file__).resolve().parent; e=root/'evidence'
report=(root/'CURRENT_STATE_B.md').read_text()
idx=json.loads((e/'evidence-index.json').read_text())
summary=json.loads((e/'closeout-summary.json').read_text())
sections=re.findall(r'^## (\d+)\. ',report,re.M)
assert sections==[str(i) for i in range(1,24)],sections
ids={x['EVIDENCE_ID'] for x in idx}; anchors={x.lower() for x in ids}
links=re.findall(r'\]\(#(ev\d+)\)',report)
assert all(x in anchors for x in links)
assert len(json.loads((e/'flow-traces.json').read_text()))==48
missing=[]
for x in idx:
    for a in x['ARTIFACT_PATH']:
        p=Path(a['path'])
        if not p.exists():missing.append(str(p))
        else:assert hashlib.sha256(p.read_bytes()).hexdigest()==a['sha256'],str(p)
assert not missing,missing
integrity=json.loads((e/'sandbox-source-integrity.json').read_text())
assert all(x['expected_sha']==x['actual_head'] and not x['tracked_status'] and not x['untracked_status'] for x in integrity)
protected=json.loads((e/'protected-comparison.json').read_text())
assert all(x['unchanged'] for x in protected['repositories'])
assert json.loads((e/'remote-comparison.json').read_text())['differences']=={}
boundary=json.loads((e/'audit-boundary.json').read_text())
assert boundary['boundary_violation'] and summary['CLOSEOUT_AUDIT']=='INCOMPLETE' and summary['BOUNDARY_VIOLATION']=='YES'
assert summary['CONFIRMED_P0_GAPS']==4 and summary['HUMAN_DECISIONS_COUNT']==6
invalid_json=[]
for p in e.rglob('*.json'):
    try:json.loads(p.read_text())
    except Exception as exc:invalid_json.append({'file':str(p),'error':str(exc)})
assert not invalid_json,invalid_json
# Only audit-generated reports/scripts were inspected; do not print possible sensitive match contents.
secret_pattern=re.compile(r'(?:ghp_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,})')
secret_findings=[str(p) for p in [root/'CURRENT_STATE_B.md',root/'AUDIT_RUN_LOG.md'] if secret_pattern.search(p.read_text())]
assert not secret_findings,secret_findings
manifest=[{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(root.rglob('*')) if p.is_file() and p.name not in ['artifact-manifest.json','report-self-check.json']]
(e/'artifact-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
check={'timestampUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':{'23_required_sections':True,'26_evidence_ids_resolve':True,'all_indexed_artifact_hashes_match':True,'48_versioned_flow_steps':True,'all_evidence_json_parse':True,'10_runtime_source_copies_clean':True,'2_protected_repositories_unchanged':True,'remote_refs_unchanged_between_reads':True,'incomplete_and_boundary_deviation_disclosed':True,'standard_token_pattern_not_found_in_reports':True},'report_sha256':hashlib.sha256((root/'CURRENT_STATE_B.md').read_bytes()).hexdigest(),'evidence_count':len(idx),'manifest_entries':len(manifest),'limits':'Consistency review of saved evidence/report, not new product execution; audit port deviation persists and is not erased by these checks.'}
(e/'report-self-check.json').write_text(json.dumps(check,ensure_ascii=False,indent=2))
with (root/'AUDIT_RUN_LOG.md').open('a') as f:f.write('\n报告一致性自检：23节/26 evidence/48 steps均对应；证据hash与JSON有效；源码副本干净；两原仓库与远端前后不变；明确INCOMPLETE与端口偏差。manifest在最后日志追加前生成，日志末尾追加影响其当时hash，见索引时间边界。\n')
print(json.dumps(check,ensure_ascii=False))

