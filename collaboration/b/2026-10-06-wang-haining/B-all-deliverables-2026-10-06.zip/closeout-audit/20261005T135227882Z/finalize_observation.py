from pathlib import Path
import datetime, hashlib, json, os, re, signal, subprocess
ROOT=Path(__file__).resolve().parent
C=json.loads((ROOT/'run-config.json').read_text()); SB=Path(C['SANDBOX_ROOT'])
ENV={**os.environ,'GIT_OPTIONAL_LOCKS':'0','GIT_NO_LAZY_FETCH':'1','GIT_NO_REPLACE_OBJECTS':'1','GIT_TERMINAL_PROMPT':'0'}
def git(p,*a):
    return subprocess.check_output(['git','--no-optional-locks','-c','core.fsmonitor=false','-C',str(p),*a],env=ENV,text=True).strip()
def h(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,d): (ROOT/'evidence'/n).write_text(json.dumps(d,ensure_ascii=False,indent=2))
start=json.loads((ROOT/'evidence/remote-heads-start.json').read_text())
start.pop('checkedAt',None);start['observedIntervalUTC']=['2026-10-05T13:52:27.882425Z','2026-10-05T13:53:50Z'];start['timePrecision']='request completion falls within recorded interval; no exact second was retained'
write('remote-heads-start.json',start)
end=json.loads((ROOT/'evidence/remote-heads-end.json').read_text())
a={r['ref']:r['object']['sha'] for r in start['refs']};b={r['ref']:r['object']['sha'] for r in end['refs']}
write('remote-comparison.json',{'start_count':len(a),'end_count':len(b),'differences':{k:{'start':a.get(k),'end':b.get(k)} for k in sorted(a.keys()|b.keys()) if a.get(k)!=b.get(k)},'scope':'authorized connector GET head refs only; no fetch; no assurance about unobserved commits between reads'})
v=json.loads((ROOT/'versions.json').read_text()); inspection=[]
patterns=['65536','Invalid request size','ls_tree_names','ls-tree','wanted_paths','collect_code_facts','prior_decisions','current_map','confirmedForRevision','git-common-dir','records.sqlite3','PROPOSED','base_revision','PROJECTMIND_REAL_','127.0.0.1", 0','127.0.0.1\', 0']
paths=['app.py','extension_host.py','extensions/code_facts/facts.py','extensions/code_facts/extension.py','extensions/map_proposal/engine.py','extensions/map_proposal/facts_adapter.py','extensions/map_proposal/extension.py','extensions/map_proposal/model.py','extensions/context_authority/context_pack.py','extensions/continuity/model.py','extensions/continuity/store.py','extensions/worklog/store.py','docs/standards/COLLABORATION_CONTRACT.md','docs/standards/MVP_INTERFACES.md','tests/test_extensions.py','tests/test_code_facts.py','tests/test_worklog.py','tests/test_continuity.py','tests/test_handoff.py','tests/test_real_b_integration.py','tests/test_real_ca_integration.py']
for key in ['BCD','UI']:
    for rel in paths:
        p=Path(v[key]['copy'])/rel
        if not p.exists(): continue
        lines=p.read_text().splitlines()
        inspection.append({'version':key,'sha':v[key]['sha'],'path':rel,'file_sha256':h(p),'matched_lines':[{'line':i+1,'text':s} for i,s in enumerate(lines) if any(t in s for t in patterns)]})
archive=Path(v['archive']['copy'])
histpaths=['docs/audits/2026-10-05-repair-run/FINAL_REPAIR_REPORT.md','docs/audits/2026-10-05-repair-run/FINDING_STATUS.md','docs/audits/2026-10-05-repair-run/STATE.json','docs/audits/2026-10-05-repair-run/REVIEW_CURSOR.json','docs/audits/2026-10-05-repair-run/RUN_LOG.md','docs/audits/2026-10-05-repair-run/NEXT_TEAM_DIVISION.md','docs/audits/2026-10-05-independent-verification.md','docs/audits/2026-10-05-independent-verification.json','docs/audits/2026-10-05-repair-run/GRILLING_SESSION.json','docs/audits/c-convergence-2026-10/overnight-run/HUMAN_DECISIONS.md']
historical=[]
for rel in histpaths:
    p=archive/rel
    if p.exists(): historical.append({'path':rel,'source_sha':v['archive']['sha'],'file_sha256':h(p),'content':p.read_text(),'scope':'archived historical source, not live Windows original or this-run execution'})
write('source-inspection.json',inspection);write('historical-documents.json',historical)
model=json.loads((ROOT/'evidence/model-documents.json').read_text())
write('model-document-hashes.json',[{'path':r['path'],'git_ref':r['gitRef'],'git_blob_sha':r['sha'],'sha256':hashlib.sha256(r['content'].encode()).hexdigest(),'approval':'draft/recorded-source; not formal approved model'} for r in model])
receiver=json.loads((ROOT/'evidence/recovery-receiver-result.json').read_text())
packet=ROOT/'evidence/recovery-packet-BCD.json'
write('recovery-validation.json',{'RECOVERY_CONTEXT_ISOLATION':'collaboration spawn fork_turns=none; only product exported packet plus expressly allowed Git metadata and two referenced blobs; sole authorized recovery subagent','INPUT_PACKET_SOURCE':str(packet),'INPUT_PACKET_HASH':h(packet),'INPUT_PACKET_BYTES':packet.stat().st_size,'ALLOWED_READ_SCOPE':['exported packet','target repo identity/HEAD/status','user.py and service.py at packet target SHA'],'ACTUAL_READ_SCOPE':receiver['actual_read_scope'],'RECOVERED_FACTS':receiver['recovered_facts'],'INCORRECT_OR_MISSING_FACTS':receiver['incorrect_or_missing_or_unknown'],'GROUND_TRUTH_EVIDENCE':['runtime-config.json','http-BCD/compare.json','http-BCD/proposal-installed-B.json','http-BCD/continuity-export.json'],'FULL_REPOSITORY_REREAD_OCCURRED':receiver['full_repository_reread_occurred'],'VERIFICATION_LIMITS':['Tiny synthetic target; two actual Git blobs only. No general token savings measurement.','C proposal body/identifier, evidence-review record and formal D1-D6 definitions were not supplied in this packet. Missing facts are correctly UNKNOWN, not proof of all D export modes being unable to carry them.','Packet commands did not authorize execution; receiving test did not execute product code.'],'receiver_sha256':h(ROOT/'evidence/recovery-receiver-result.json')})
# Stop only own recorded runtime PIDs, after verifying each command still belongs to this sandbox.
stop=[]
for row in json.loads((ROOT/'processes.json').read_text()):
    try:
        p=subprocess.run(['ps','-p',str(row['pid']),'-o','command='],capture_output=True,text=True)
    except PermissionError:
        stop.append({'pid':row['pid'],'version':row['version'],'result':'NOT_STOPPED: process identity inspection ps blocked by sandbox; no unverified PID was killed'})
        continue
    cmd=p.stdout.strip(); item={'pid':row['pid'],'version':row['version'],'observed_command':cmd}
    if not cmd:item['result']='already stopped'
    elif str(SB) in cmd and row['target'] in cmd:
        os.kill(row['pid'],signal.SIGTERM);item['result']='SIGTERM sent to own recorded process'
    else:item['result']='NOT_STOPPED: PID identity mismatch'
    stop.append(item)
write('own-process-stop.json',stop)
def snapshot(p):
    p=Path(p)
    return {'path':str(p),'HEAD':git(p,'rev-parse','HEAD'),'refs':git(p,'show-ref'),'branch':git(p,'branch','--show-current'),'tracked':git(p,'status','--porcelain','--untracked-files=no'),'untracked':git(p,'ls-files','--others','--exclude-standard'),'worktrees':git(p,'worktree','list','--porcelain'),'file_hashes':{str(f.relative_to(p)):h(f) for f in p.rglob('*') if f.is_file() and '.git' not in f.parts},'git_index_hash':h(p/'.git/index')}
protected_start=json.loads((ROOT/'evidence/protected-start.json').read_text())
protected_end={'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repositories':[snapshot(r['path']) for r in protected_start['repositories']]}
write('protected-end.json',protected_end)
comparisons=[]
for before,after in zip(protected_start['repositories'],protected_end['repositories']):
    changed={k:True for k in before if before[k]!=after[k]}
    comparisons.append({'path':before['path'],'changed_fields':changed,'unchanged':not changed,'registered_checkout_count':after['worktrees'].count('worktree ')})
write('protected-comparison.json',{'scope':'two explicit Mac protected repositories; Windows workspaces unavailable','repositories':comparisons,'external_drift_observed':any(not x['unchanged'] for x in comparisons)})
write('sandbox-source-integrity.json',[{'version':k,'expected_sha':x['sha'],'actual_head':git(x['copy'],'rev-parse','HEAD'),'tracked_status':git(x['copy'],'status','--porcelain','--untracked-files=no'),'untracked_status':git(x['copy'],'ls-files','--others','--exclude-standard')} for k,x in v.items()])
write('audit-boundary.json',{'protected_code_modified':False,'protected_shared_state_modified':False,'main_modified':False,'main_merged':False,'main_pushed':False,'manual_service_ports':[18820,18821,18822,18823],'boundary_violation':True,'violation':'Unchanged existing unittest HTTP fixtures were executed with bind port 0 (system-assigned ephemeral ports); the B-only allocation restriction was not applied to those listeners. Exact allocated port numbers were not retained. This is an audit-process deviation, not a product-code change.','impact':'Loopback test servers in own sandbox; tests shut down their own servers. No evidence of protected process interruption or shared-state changes. Do not erase or rerun to conceal deviation.','missing_scope':['Windows <WINDOWS_WORKSPACE> repositories/worktree inventory and Temp legacy path','Windows original navigation/state files not found in pinned archive','live Grilling continuity/session'],'browser_downloads':'NOT_RUN; UI enabled and preview tested, JSON body saved via API','cleanup':'No audit/sandbox roots removed; PID inspection blocked, own runtime processes not killed; status in own-process-stop.json'})
print(json.dumps({'protected':comparisons,'remote_changed':a!=b,'source_integrity_saved':True,'receiver_sha256':h(ROOT/'evidence/recovery-receiver-result.json'),'audit_boundary_deviation':True},ensure_ascii=False))
