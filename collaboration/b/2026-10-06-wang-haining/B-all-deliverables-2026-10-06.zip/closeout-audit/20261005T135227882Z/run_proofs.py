from pathlib import Path
import datetime,json,os,runpy,subprocess,sys
from unittest.mock import patch
ROOT=Path(__file__).resolve().parent;C=json.loads((ROOT/'run-config.json').read_text());V=json.loads((ROOT/'versions.json').read_text())
SB=Path(C['SANDBOX_ROOT']);source=Path(V['BCD']['copy'])
os.environ.update(PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(SB/'tmp'),TEMP=str(SB/'tmp'),TMP=str(SB/'tmp'),PROJECTMIND_REAL_B_ROOT=str(source),PROJECTMIND_REAL_CA_ROOT=str(source))
sys.dont_write_bytecode=True
env={**os.environ}; env['PATH']='<LOCAL_USER_HOME>/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin'+os.pathsep+env['PATH']
for mode,script in [('matrix','acceptance_matrix.py'),('mutation','mutation_runner.py')]:
    report=ROOT/'evidence'/(mode+'-BCD.json');log=ROOT/'evidence'/(mode+'-BCD.log')
    command=[sys.executable,str(source/'tests'/script),'--json',str(report)]
    if mode=='matrix':
        with log.open('w') as stream:result=subprocess.run(command,cwd=source,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
        print(json.dumps({'mode':mode,'exit_code':result.returncode,'report':str(report)}),flush=True)
    else:
        # Preserve mutation clones as audit artifacts, without changing runner source.
        os.chdir(source);sys.argv=command[1:];os.environ.update(env)
        with log.open('w') as stream,patch('shutil.rmtree',lambda *args,**kwargs:None),patch('sys.stdout',stream),patch('sys.stderr',stream):
            runpy.run_path(str(source/'tests'/script),run_name='__main__')
        print(json.dumps({'mode':mode,'report':str(report),'cleanup':'external harness preserved sandbox mutation clones'}),flush=True)
