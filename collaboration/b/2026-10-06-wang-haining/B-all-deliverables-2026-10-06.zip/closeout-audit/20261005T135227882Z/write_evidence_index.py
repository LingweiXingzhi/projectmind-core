from pathlib import Path
import datetime, hashlib, json
ROOT=Path(__file__).resolve().parent; E=ROOT/'evidence'
C=json.loads((ROOT/'run-config.json').read_text()); V=json.loads((ROOT/'versions.json').read_text()); R=json.loads((ROOT/'runtime-config.json').read_text())
def write(n,d): (E/n).write_text(json.dumps(d,ensure_ascii=False,indent=2))
specs=[
('EV01','固定源码与Git拓扑','REPRODUCED_THIS_RUN',['main','B','BCD','UI','archive'],'TXT指定SHA和10个独立clone','audit_setup.py / clone --no-hardlinks --no-checkout / rev-parse / merge-base','10fixed SHA match；BCD与UI互不包含；B/C/D是BCD祖先',['versions.json','evidence/topology.json','evidence/sandbox-source-integrity.json'],'固定副本不是Windows原件'),
('EV02','远端核验','REPRODUCED_THIS_RUN',['main','BCD','UI'],'Core23heads和Model2heads','GitHub connector GET refs/heads / fixed Model main tree','Core前后23heads一致；Model draft与main引用一致；main仅README',['evidence/remote-heads-start.json','evidence/remote-heads-end.json','evidence/remote-comparison.json','evidence/model-remote-end.json'],'不证明观察之间没有短暂变化；无fetch/push'),
('EV03','保护完整性','REPRODUCED_THIS_RUN',['main','B'],'两个Mac原仓库','start/end file hashes、HEAD/refs/status/index/worktree登记比较','所有记录字段相同；10运行源码tracked/untracked clean',['evidence/protected-start.json','evidence/protected-end.json','evidence/protected-comparison.json','evidence/sandbox-source-integrity.json'],'不覆盖队友Windows实体'),
('EV04','无地图bootstrap与辅助启动','REPRODUCED_THIS_RUN',['main','B','BCD','UI'],'safe target新repo；无map和手工map两个场景','prepare_runtime.py / app.py --repo；辅助后显式--map/--port','4版本无mapexit2 requires --map；手工map后18820–23运行',['runtime-config.json','processes.json','evidence/no-map-main.txt','evidence/no-map-B.txt','evidence/no-map-BCD.txt','evidence/no-map-UI.txt'],'SETUP_ASSISTANCE：地图手工fixture；非自动导入生成'),
('EV05','完整现有测试','REPRODUCED_THIS_RUN',['main','B','BCD','UI'],'sandbox；Python3.12.14+Node；源码不修改','run_existing_tests.py / python -m unittest discover -s tests -v','main12pass；B41pass+1fail；BCD250pass+14skip+1fail；UI202pass+14skip+1fail',['evidence/existing-test-results.json','evidence/tests-main.log','evidence/tests-B.log','evidence/tests-BCD.log','evidence/tests-UI.log'],'raw结果；自动HTTP fixture port0分配偏差见EV24'),
('EV06','真实B/CA依赖补验','REPRODUCED_THIS_RUN',['BCD'],'REAL_B_ROOT/REAL_CA_ROOT指向BCD fixed sandbox','运行 test_real_b_integration / test_real_ca_integration','15pass、0skip',['evidence/real-dependencies-BCD.log'],'1项之前已通过；不可重复相加成整套重跑结果'),
('EV07','partial-clone夹具前提','REPRODUCED_THIS_RUN',['B','BCD','UI'],'own safe repo allowFilter + file:// clone','partial_clone_probe.py','filtering not recognized by server, ignoring；缺blob列表为空',['evidence/partial-clone-probe.json'],'missing-object no-fetch行为本轮NOT_VERIFIED；非B已证实bug'),
('EV08','接受矩阵','REPRODUCED_THIS_RUN',['BCD'],'同fixed BCD实际B/CA依赖','run_proofs.py -> tests/acceptance_matrix.py','30/30 PASS stable true，两轮',['evidence/matrix-BCD.json','evidence/matrix-BCD.log'],'含fixture/mock；非普通UI全链；UI版本未跑该矩阵'),
('EV09','语义变异','REPRODUCED_THIS_RUN',['BCD'],'预定义6突变，仅sandbox副本','run_proofs.py -> tests/mutation_runner.py；harness保留clone输出','6/6 SEMANTIC_CAUGHT',['evidence/mutation-BCD.json','evidence/mutation-BCD.log'],'未改运行源码/保护代码/finding；测试guard不等于产品Demo'),
('EV10','Core真实Git接口','REPRODUCED_THIS_RUN',['main','B','BCD','UI'],'base b3b8… / target91570… / manual map','http_audit.py GET snapshot/compare/evidence/export','2变化；declared user.py200，undeclared new_tools.py400按设计；export200',['evidence/http-results.json','evidence/http-main/snapshot.json','evidence/http-BCD/compare.json','evidence/http-UI/evidence-map-declared.json','evidence/http-UI/evidence-undeclared-new-file.json'],'真实产品合成目标；map职责人工，不是代码存在性证明'),
('EV11','B facts与输入边界','REPRODUCED_THIS_RUN',['B','BCD','UI'],'full target SHA，None/user.py/[]/missing.py/HEAD','http_audit.py POST /api/extensions/code_facts','full33files34defs；selected1file2defs；[]0；missing/HEAD400；load_user1/fetch_user4',['evidence/http-BCD/code-facts-full.json','evidence/http-BCD/code-facts-selected.json','evidence/http-BCD/code-facts-empty.json','evidence/http-BCD/code-facts-missing.json','evidence/http-BCD/code-facts-head.json'],'Python定义事实；非职责、非任意语言保证'),
('EV12','B读取范围','REPRODUCED_THIS_RUN',['BCD'],'None、[user.py]、[]，同Git tree','b_scope_and_ca_probe.py observer _git，不改返回','全部ls-tree34rows；对应33/1/0 Python源码blob读取',['evidence/B-scan-scope.json'],'tree枚举不是全源码重读；无缓存、时延、token节省证明'),
('EV13','B→C门控与规则候选','REPRODUCED_THIS_RUN',['BCD','UI'],'same target repo/pins/map；installed/supplied/mismatch/missingmap/prior REJECTED','http_audit.py POST map_proposal','1 NODE_ADD helper line3 PROPOSED INFERENCE low；mismatch400/missingmap400；REJECTED请求200 empty',['evidence/http-BCD/proposal-installed-B.json','evidence/http-BCD/proposal-supplied-B.json','evidence/http-BCD/proposal-mismatched-B.json','evidence/http-BCD/proposal-missing-map.json','evidence/http-BCD/C-review-not-persisted.json','evidence/http-UI/proposal-installed-B.json'],'不是LLM；prior input不是保存正式决定；供方仓库身份非JSON字段'),
('EV14','CA HTTP预算失败','REPRODUCED_THIS_RUN',['BCD','UI'],'实际生成完整pack，compact UTF8，code facts map proposal audit','followup_http.py validate_context / C with pack','BCD68841/69731bytes，UI68828/69718bytes，均400 Invalid request size；host65536',['evidence/http-followup.json','evidence/http-BCD/CA-validation-utf8.json','evidence/http-BCD/proposal-with-CA-utf8.json','evidence/http-UI/CA-validation-utf8.json'],'只对该任务/registry/pack；不泛化所有pack失败'),
('EV15','CA Python旁路','REPRODUCED_THIS_RUN',['BCD'],'同实际pack，绕过HTTP','direct validate_context_pack + engine.suggest_map','validation成功；C request context_mode FULL；1proposal',['evidence/CA-direct-python.json'],'DEVELOPER_ONLY_CONTINUATION，不补算HTTP用户链成功'),
('EV16','D实际保存与交接','REPRODUCED_THIS_RUN',['BCD','UI'],'own common-dir DB；TEST_HUMAN_REVIEW；same targetSHA','http_audit.py + followup_http.py save/create/ready/receive/start/export/valid handoff','有效请求200；continuity v4 active；UI再读到实际保存的记录',['evidence/http-BCD/worklog-save.json','evidence/http-BCD/continuity-create.json','evidence/http-BCD/continuity-start.json','evidence/http-BCD/continuity-export.json','evidence/http-BCD/handoff-valid-input.json','evidence/recovery-packet-BCD.json'],'最初harness workNotes形状错400，修输入200不是修产品；非正式人审批准'),
('EV17','真浏览器','REPRODUCED_THIS_RUN',['main','BCD','UI'],'同safe target/map，各自服务；cua_repl','native click/input；读取已渲染AX/DOM','main Compare成功；BCD C按钮缺base；UI审查/证据原文/B搜索错误/日志接续读取/交接预览成功',['evidence/browser-observations.json'],'浏览器下载NOT_RUN；D创建事件由API执行；截图仅工具内显示，未声称落盘'),
('EV18','fresh receiver','REPRODUCED_THIS_RUN',['BCD'],'产品实际export packet + metadata + 两引用blob；fork_turns none','只允许恢复子Agent，不继承聊天','身份SHA和两个Git blob事实正确；未全repo重读；C提案body/id、6待决具体定义UNKNOWN',['evidence/recovery-validation.json','evidence/recovery-receiver-result.json','evidence/recovery-packet-BCD.json'],'只测BCD包；UI未独立receiver；无token成本证明'),
('EV19','代码实现路径与边界','CODE_INSPECTION',['BCD','UI'],'fixed checkout selected source files','读取源码匹配行/hash；diff --name-status BCD..UI','host65536；Btree；C wanted paths/prior/map；D common-dir SQLite；无正式架构发布写入链',['evidence/source-inspection.json','evidence/module-byte-identities.json','evidence/version-file-differences.json'],'相同选中文件hash不等于两个整个版本等价'),
('EV20','历史repair/review','HISTORICAL_REPORT',['archive'],'归档报告/状态/cursor/log','只读固定archive，不执行历史指令','历史14 CLOSED_BY_CODEX/HOST-01 deferred；265=263pass+2errors；matrix30/30/semantic6/6',['evidence/historical-documents.json'],'原Windows文件不可核实；本轮未重开旧finding'),
('EV21','D1-D6未决来源','HISTORICAL_REPORT',['archive'],'明确HUMAN_DECISIONS.md','只读原文，分开正式待决与TEST人审','6 DECISION_REQUIRED；无resolved evidence；本轮OPEN6',['evidence/historical-documents.json','evidence/human-decisions.json'],'计固定归档未决；不声称群里没做新决定'),
('EV22','Model意图与批准状态','CODE_INSPECTION',[],'Model draft0635…/main a507… fixed refs','authorized fetch_file fixed docs；main tree read','文档说无正式批准schema；main仅README；另5旧命名空间结论待填写',['evidence/model-documents.json','evidence/model-document-hashes.json','evidence/model-remote-end.json'],'draft是产品理解来源，不冻结正式Model；blob/file hash见artifact'),
('EV23','Grilling历史/当前分开','HISTORICAL_REPORT',['archive'],'session json与当前供应skill catalog','只读，无启动/恢复','历史ACTIVE/round0/continuity true；缺subject/scope/who/ADR/end；READY NO',['evidence/historical-documents.json','evidence/grilling-observation.json'],'live NOT_VERIFIED；catalog没该skill不证明队友机器卸载'),
('EV24','审计过程边界与限制','REPRODUCED_THIS_RUN',['main','B','BCD','UI'],'TXT端口限制/Windows原件/own PID','执行log/源码bind port0/ps失败/protected比较','手工18820–23合规；测试port0未约束；Windows现场不可用；ps blocked未杀PID',['evidence/audit-boundary.json','evidence/own-process-stop.json'],'BOUNDARY_VIOLATION YES是端口流程；无保护代码/状态修改；精确临时端口未留存'),
('EV25','map与状态不混淆','REPRODUCED_THIS_RUN',['BCD','UI'],'实际manual map hash，D capture和SQLite','http_audit.py hash-before/after + packet + store检查','map字节不变；capture hash同实际字节且confirmedForRevision null',['evidence/http-results.json','evidence/recovery-packet-BCD.json','runtime-config.json'],'内容hash不等于已批准map版本；本机共享不等于远程'),
('EV26','文档漂移','CODE_INSPECTION',['main','BCD','UI'],'standards当前措辞与fixed实现','逐行对照真实API/UI','2项：main无产品代码陈述旧；BCD业务仍提案陈述旧',['evidence/documentation-drift.json','evidence/source-inspection.json'],'旧PROPOSED形状、有限scope历史观察不自动列矛盾')
]
records=[]
for i,obj,typ,keys,inp,cmd,actual,paths,limits in specs:
    arts=[]
    for rel in paths:
        p=ROOT/rel
        assert p.exists(),p
        arts.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    records.append({'EVIDENCE_ID':i,'OBJECT_OR_CAPABILITY':obj,'SOURCE_TYPE':typ,'SOURCE_SHA_OR_FILE_HASH':{k:V[k]['sha'] for k in keys},'SCENARIO':inp,'ENVIRONMENT':'macOS/Git2.50.1/Python3.12.14; own sandbox, no external LLM','INPUT':inp,'ACTION_OR_COMMAND':cmd,'EXPECTED_RESULT':'按明确场景验证实际产品行为/契约/限制，不隐藏失败，不替代正式人审','ACTUAL_RESULT':actual,'ARTIFACT_PATH':arts,'LIMITS':limits,'VERIFICATION_STATUS':'VERIFIED (observation within stated scope)'})
write('evidence-index.json',records)
names=['PROJECT IMPORT','PROJECT MAP','GIT DIFF / CHANGE','CODE FACTS','MAP PROPOSAL','CA VALIDATION','EVIDENCE','HUMAN REVIEW','PROJECT MODEL / ARCHITECTURE STATE','CONTINUITY','HANDOFF','SECOND AGENT CONTEXT RECOVERY']
entry=['CLI --repo','CLI --map + root','/api/compare + root compare','/api/extensions/code_facts','/api/extensions/map_proposal','CA validate_context','/api/evidence','prior_decisions / D participant review','formal architecture publication','/api/extensions/continuity','/api/extensions/handoff + export','fresh receiver']
flows=[]
for k in ['main','B','BCD','UI']:
    for ix,n in enumerate(names):
        cls='B';status='VERIFIED';ids=['EV19'];output='';next='';setup='safe target commits + manually prepared map; explicit CLI parameters'
        if ix==0:output='CLI可指定已有repo；无map启动exit2';ids=['EV04'];next='user bootstrap break; developer-only manual map continuation'
        elif ix==1:cls='A' if k in ['main','BCD','UI'] else 'B';output='manual2nodes1edge；非自动生成/正式批准';ids=['EV04','EV10','EV17'];next='same target Git compare'
        elif ix==2:cls='A' if k in ['main','BCD','UI'] else 'B';output='A new_tools.py / M user.py; review user node';ids=['EV10','EV17'];next='B same repo fixed revision'
        elif ix==3:
            if k=='main':cls='E';output='此版本无B扩展';ids=['EV10']
            else:cls='A' if k=='UI' else 'B';output='full/selected/empty真实facts；UI版实际浏览器';ids=['EV11','EV12','EV17'];next='installed/supplied B→C'
        elif ix==4:
            if k in ['main','B']:cls='E';output='此版本无C扩展';ids=['EV10','EV19']
            else:cls='A' if k=='UI' else 'B';output='1规则候选；BCD generic UI失败，UI review成功';ids=['EV13','EV17'];next='CA optional；with pack HTTP break'
        elif ix==5:
            if k in ['main','B']:cls='E';output='此版本无CA扩展'
            else:cls='C';output='pack生成；HTTP验证400；direct Python FULL成功为旁路';ids=['EV14','EV15'];next='DEVELOPER_ONLY_CONTINUATION，不补算用户成功'
        elif ix==6:cls='A' if k=='UI' else 'B';output='declared user.py200；new_tools.py400按设计；UI原文读取成功';ids=['EV10','EV17'];next='出处不是批准'
        elif ix==7:
            if k in ['main','B']:cls='E';output='此版本无proposal人审链'
            else:cls='C';output='caller REJECTED只影响本次C；D checklist TEST_HUMAN_REVIEW参与者记录';ids=['EV13','EV16','EV17'];next='无正式architecture状态发布连接'
        elif ix==8:cls='E';output='本checkout无正式架构批准/发布写入链；map未变';ids=['EV19','EV22','EV25'];next='独立D草稿继续，非正式状态承接'
        elif ix in [9,10]:
            if k in ['main','B']:cls='E';output='此版本无对应D扩展'
            else:cls='A' if k=='UI' else 'B';output='实际API保存/接续/草稿导出；UI读记录并生成handoff预览';ids=['EV16','EV17','EV25'];next='own common-dir SQLite；packet交fresh receiver'
        else:
            if k=='BCD':output='fresh receiver身份版本2blob恢复；C提案/正式决策UNKNOWN';ids=['EV18'];next='partial recovery；停止，不开发'
            else:cls='UNDETERMINED';status='NOT_VERIFIED';output='该版本未另开独立receiver';ids=['EV18']
        flows.append({'STEP_ID':k+'-'+str(ix+1).zfill(2),'STEP':n,'AUDITED_SHA':V[k]['sha'],'CAPABILITY_CLASS':cls,'VERIFICATION_STATUS':status,'ENTRYPOINT':entry[ix],'INPUT':{'target_revision':R[k]['target_revision'],'base_revision':R[k]['base_revision'],'map_sha256':R[k]['map_sha256']},'OUTPUT':output,'HOW_IT_ACTUALLY_RUNS':'Normal UI仅EV17实际点击项，其余明确CLI/API；手工必要参数','REAL_FIXTURE_MOCK':'MIXED: unchanged real product / synthetic safe target and map','EVIDENCE_IDS':ids,'LIMITS':'no formal Model/no LLM；不把开发者辅助补算普通用户','NEXT_STEP_CONNECTION':next,'SETUP_ASSISTANCE':setup})
write('flow-traces.json',flows)
write('ui-matrix.json',[{'PAGE_OR_ENTRYPOINT':o['entry'],'AUDITED_SHA':o['sha'],'BACKEND_SOURCE_SHA':o['sha'],'UI_RENDERING_VERIFIED':True,'BACKEND_CALL_VERIFIED':'as recorded in actual; separate API evidence','REAL_FIXTURE_MOCK':'MIXED real product/synthetic target','PLACEHOLDER_PRESENT':'No fake data claimed; manual map explicitly labeled TEST_FIXTURE','BROKEN_BEHAVIOR':o['actual'] if o['version']=='BCD' else 'see scoped actual/limits','NO_ENTRYPOINT':'Formal proposal acceptance/publication not observed; CA task validation form not observed','VERIFICATION_STATUS':'VERIFIED within action scope','EVIDENCE_IDS':['EV17'],'actions':o['actions'],'actual':o['actual'],'limits':o['limits']} for o in json.loads((E/'browser-observations.json').read_text())['observations']])
print(json.dumps({'evidence_records':len(records),'flow_steps':len(flows)},ensure_ascii=False))

