from pathlib import Path
import json,os,subprocess
ROOT=Path(__file__).resolve().parent;cfg=json.loads((ROOT/'run-config.json').read_text());SB=Path(cfg['SANDBOX_ROOT'])
source=SB/'partial-probe-source';partial=SB/'partial-probe-copy';source.mkdir()
commands=[];env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
def git(repo,*args):
    command=['git','-C',str(repo),'-c','user.name=Test','-c','user.email=test@example.invalid','-c','commit.gpgsign=false',*args]
    r=subprocess.run(command,env=env,capture_output=True,text=True)
    commands.append({'command':command,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
    if r.returncode:raise RuntimeError(r.stderr)
    return r.stdout.strip()
git(source,'init');(source/'sample.py').write_text('def example():\n    pass\n')
git(source,'add','.');git(source,'commit','-m','fixture')
sha=git(source,'rev-parse','HEAD');blob=git(source,'rev-parse',sha+':sample.py')
git(source,'config','uploadpack.allowFilter','true');git(source,'config','uploadpack.allowAnySHA1InWant','true')
git(source,'clone','--quiet','--no-checkout','--filter=blob:none',source.as_uri(),str(partial))
missing=git(partial,'--no-lazy-fetch','rev-list','--objects','--all','--missing=print')
result={'sha':sha,'blob':blob,'missing':missing,'commands':commands}
(ROOT/'evidence/partial-clone-probe.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False,indent=2))
